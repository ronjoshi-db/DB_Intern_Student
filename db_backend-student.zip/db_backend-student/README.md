# Student Back-end

## Python Flask API 

Created by Victoria Lloyd  
*Last updated June 2021*